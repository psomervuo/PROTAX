Probabilistic Taxonomic Classifier PROTAX
=========================================

This demonstrates how to to train a model and use it to classify new sequences.
A separate model is trained for each level of the taxonomy.

The example uses fungal taxonomy and reference sequences.
Predictors are based on sequence similarities calculated with usearch_global,
they include best similarity and 97% quantile similarity for each taxon.

The framework should be flexible to add and include user-defined predictors.
Scripts are in directory protaxscripts and there are 4 step-files for the following tasks:

step1: set up the system with existing taxonomy and reference sequences
step2: train a model using MCMC
step3: validate a model using subset of reference sequences
step4: classify new sequences
